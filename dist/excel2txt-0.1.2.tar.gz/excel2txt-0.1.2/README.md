# excel2txt

Convert Excel files to delimited text.

# Install

```
$ python -m pip install -r requirements.txt
```

# Author

Ken Youens-Clark <kyclark@gmail.com>
